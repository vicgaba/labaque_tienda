<?php

namespace App\Http\Controllers;

use App\Models\CustomerOrder;
use App\Models\Client;
use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class CustomerOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $customerOrders = CustomerOrder::with(['client.user', 'customerOrderItems.product'])
                                       ->latest()
                                       ->paginate(10);
        return view('customer_orders.index', compact('customerOrders'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        $clients = Client::with('user')->get();
        $products = Product::where('active', true)->where('stock', '>', 0)->orderBy('name')->get();
        return view('customer_orders.create', compact('clients', 'products'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        // Debug: Log los datos recibidos
        Log::info('CustomerOrder Store - Request data:', $request->all());

        // Validación mejorada
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'product_ids' => 'required|array|min:1',
            'product_ids.*' => 'required|exists:products,id',
            'quantities' => 'required|array|min:1',
            'quantities.*' => 'required|integer|min:1',
            'shipping_address' => 'nullable|string|max:500',
            'status' => 'required|in:pending,processing,completed,cancelled',
        ]);

        // Verificar que product_ids y quantities tengan el mismo tamaño
        if (count($validated['product_ids']) !== count($validated['quantities'])) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['quantities' => 'La cantidad de productos y cantidades no coincide.']);
        }

        DB::beginTransaction();

        try {
            $totalAmount = 0;
            $orderItemsData = [];

            // Verificar stock y calcular total
            foreach ($validated['product_ids'] as $index => $productId) {
                $product = Product::find($productId);
                $quantity = (int) $validated['quantities'][$index];

                if (!$product) {
                    DB::rollBack();
                    return redirect()->back()
                        ->withInput()
                        ->withErrors(['product_ids' => "Producto con ID {$productId} no encontrado."]);
                }

                if ($product->stock < $quantity) {
                    DB::rollBack();
                    return redirect()->back()
                        ->withInput()
                        ->withErrors(['quantities' => "Stock insuficiente para {$product->name}. Stock disponible: {$product->stock}"]);
                }

                $orderItemsData[] = [
                    'product_id' => $productId,
                    'quantity' => $quantity,
                    'price_at_order' => $product->price,
                ];
                
                $totalAmount += ($quantity * $product->price);
            }

            // Crear el pedido del cliente
            $customerOrder = CustomerOrder::create([
                'client_id' => $validated['client_id'],
                'total_amount' => $totalAmount,
                'status' => $validated['status'],
                'shipping_address' => $validated['shipping_address'],
            ]);

            Log::info('CustomerOrder created:', ['id' => $customerOrder->id]);

            // Crear los ítems del pedido
            foreach ($orderItemsData as $itemData) {
                $customerOrder->customerOrderItems()->create($itemData);

                // Actualizar el stock del producto
                $product = Product::find($itemData['product_id']);
                if ($product) {
                    $product->decrement('stock', $itemData['quantity']);
                    
                    // Crear movimiento de stock (verificar si el método existe)
                    if (method_exists($customerOrder, 'stockMovements')) {
                        $customerOrder->stockMovements()->create([
                            'product_id' => $itemData['product_id'],
                            'user_id' => Auth::id(),
                            'type' => 'out',
                            'quantity' => $itemData['quantity'],
                            'reason' => 'Venta a cliente',
                        ]);
                    }
                }
            }

            DB::commit();
            
            return redirect()->route('customer-orders.index')
                ->with('success', 'Venta registrada exitosamente.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('CustomerOrder store error:', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
            
            return redirect()->back()
                ->withInput()
                ->withErrors(['general' => 'Error al registrar la venta: ' . $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(CustomerOrder $customerOrder): View
    {
        $customerOrder->load(['client.user', 'customerOrderItems.product']);
        return view('customer_orders.show', compact('customerOrder'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CustomerOrder $customerOrder): View
    {
        $customerOrder->load(['client.user', 'customerOrderItems.product']);
        return view('customer_orders.edit', compact('customerOrder'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CustomerOrder $customerOrder): RedirectResponse
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,processing,completed,cancelled',
            'shipping_address' => 'nullable|string|max:500',
        ]);

        $customerOrder->update($validated);

        return redirect()->route('customer-orders.index')
            ->with('success', 'Estado del pedido actualizado exitosamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CustomerOrder $customerOrder): RedirectResponse
    {
        return redirect()->route('customer-orders.index')
            ->with('error', 'La eliminación directa de pedidos históricos no está permitida para evitar inconsistencias de stock. Por favor, cambie el estado del pedido a "cancelado" si es necesario.');
    }
}