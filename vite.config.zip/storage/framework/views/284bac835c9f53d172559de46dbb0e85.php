<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Productos')); ?>

            </h2>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('products.export')); ?>" 
                   class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Exportar CSV
                </a>
                <a href="<?php echo e(route('products.create')); ?>" 
                   class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Nuevo Producto
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!-- Filtros -->
                <div class="p-6 bg-gray-50 border-b border-gray-200">
                    <form method="GET" action="<?php echo e(route('products.index')); ?>" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                        <!-- Búsqueda -->
                        <div>
                            <input type="text" 
                                   name="search" 
                                   value="<?php echo e(request('search')); ?>"
                                   placeholder="Buscar por nombre, SKU o marca..."
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>

                        <!-- Categoría -->
                        <div>
                            <select name="category_id" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Todas las categorías</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Estado -->
                        <div>
                            <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Todos los estados</option>
                                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Activos</option>
                                <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactivos</option>
                            </select>
                        </div>

                        <!-- Stock bajo -->
                        <div class="flex items-center">
                            <input type="checkbox" 
                                   name="low_stock" 
                                   value="1" 
                                   <?php echo e(request('low_stock') ? 'checked' : ''); ?>

                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label class="ml-2 block text-sm text-gray-700">Stock bajo</label>
                        </div>

                        <!-- Botones -->
                        <div class="flex space-x-2">
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Filtrar
                            </button>
                            <a href="<?php echo e(route('products.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                                Limpiar
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Acciones masivas -->
                <div class="p-4 bg-yellow-50 border-b border-gray-200">
                    <form id="bulk-form" method="POST" action="<?php echo e(route('products.bulk-action')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="flex items-center space-x-4">
                            <select name="action" class="px-3 py-2 border border-gray-300 rounded-md">
                                <option value="">Seleccionar acción</option>
                                <option value="activate">Activar seleccionados</option>
                                <option value="deactivate">Desactivar seleccionados</option>
                                <option value="delete">Eliminar seleccionados</option>
                            </select>
                            <button type="submit" class="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded">
                                Aplicar
                            </button>
                            <span class="text-sm text-gray-600">
                                <span id="selected-count">0</span> productos seleccionados
                            </span>
                        </div>
                    </form>
                </div>

                <!-- Tabla de productos -->
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <input type="checkbox" id="select-all" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Imagen
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <a href="<?php echo e(request()->fullUrlWithQuery(['sort_by' => 'name', 'sort_order' => request('sort_order') === 'asc' ? 'desc' : 'asc'])); ?>" class="hover:text-gray-700">
                                        Producto
                                        <?php if(request('sort_by') === 'name'): ?>
                                            <span class="ml-1"><?php echo e(request('sort_order') === 'asc' ? '↑' : '↓'); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    SKU
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Categoría
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <a href="<?php echo e(request()->fullUrlWithQuery(['sort_by' => 'price', 'sort_order' => request('sort_order') === 'asc' ? 'desc' : 'asc'])); ?>" class="hover:text-gray-700">
                                        Precio
                                        <?php if(request('sort_by') === 'price'): ?>
                                            <span class="ml-1"><?php echo e(request('sort_order') === 'asc' ? '↑' : '↓'); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <a href="<?php echo e(request()->fullUrlWithQuery(['sort_by' => 'stock', 'sort_order' => request('sort_order') === 'asc' ? 'desc' : 'asc'])); ?>" class="hover:text-gray-700">
                                        Stock
                                        <?php if(request('sort_by') === 'stock'): ?>
                                            <span class="ml-1"><?php echo e(request('sort_order') === 'asc' ? '↑' : '↓'); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Estado
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Acciones
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <input type="checkbox" name="products[]" value="<?php echo e($product->id); ?>" class="product-checkbox h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($product->image_path): ?>
                                            <img src="<?php echo e(Storage::url($product->image_path)); ?>" 
                                                 alt="<?php echo e($product->name); ?>" 
                                                 class="h-16 w-16 object-cover rounded-lg">
                                        <?php else: ?>
                                            <div class="h-16 w-16 bg-gray-200 rounded-lg flex items-center justify-center">
                                                <span class="text-gray-400 text-xs">Sin imagen</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo e($product->name); ?></div>
                                        <?php if($product->brand): ?>
                                            <div class="text-sm text-gray-500"><?php echo e($product->brand); ?></div>
                                        <?php endif; ?>
                                        <?php if($product->size || $product->color): ?>
                                            <div class="text-xs text-gray-400">
                                                <?php if($product->size): ?> Talla: <?php echo e($product->size); ?> <?php endif; ?>
                                                <?php if($product->color): ?> Color: <?php echo e($product->color); ?> <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e($product->sku); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e($product->category->name ?? 'Sin categoría'); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        $<?php echo e(number_format($product->price, 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <span class="<?php if($product->stock < 10): ?> text-red-600 font-semibold <?php endif; ?>">
                                            <?php echo e($product->stock); ?>

                                        </span>
                                        <?php if($product->stock < 10): ?>
                                            <span class="text-xs text-red-500 block">Stock bajo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <form method="POST" action="<?php echo e(route('products.toggle', $product)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($product->active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                                <?php echo e($product->active ? 'Activo' : 'Inactivo'); ?>

                                            </button>
                                        </form>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex space-x-2">
                                            <a href="<?php echo e(route('products.show', $product)); ?>" class="text-blue-600 hover:text-blue-900">Ver</a>
                                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="text-indigo-600 hover:text-indigo-900">Editar</a>
                                            <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" class="inline" onsubmit="return confirm('¿Estás seguro de que quieres eliminar este producto?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-600 hover:text-red-900">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                                        No se encontraron productos.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <div class="px-6 py-4 border-t border-gray-200">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        // Seleccionar todos los checkboxes
        document.getElementById('select-all').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.product-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelectedCount();
        });

        // Actualizar contador de seleccionados
        document.querySelectorAll('.product-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectedCount);
        });

        function updateSelectedCount() {
            const selected = document.querySelectorAll('.product-checkbox:checked').length;
            document.getElementById('selected-count').textContent = selected;
            
            // Agregar los IDs seleccionados al formulario
            const form = document.getElementById('bulk-form');
            // Remover inputs anteriores
            form.querySelectorAll('input[name="products[]"]').forEach(input => input.remove());
            
            // Agregar nuevos inputs
            document.querySelectorAll('.product-checkbox:checked').forEach(checkbox => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'products[]';
                input.value = checkbox.value;
                form.appendChild(input);
            });
        }

        // Confirmar acciones masivas
        document.getElementById('bulk-form').addEventListener('submit', function(e) {
            const action = this.querySelector('select[name="action"]').value;
            const selected = document.querySelectorAll('.product-checkbox:checked').length;
            
            if (!action) {
                e.preventDefault();
                alert('Por favor selecciona una acción.');
                return;
            }
            
            if (selected === 0) {
                e.preventDefault();
                alert('Por favor selecciona al menos un producto.');
                return;
            }
            
            let message = '';
            switch(action) {
                case 'delete':
                    message = `¿Estás seguro de que quieres eliminar ${selected} productos?`;
                    break;
                case 'activate':
                    message = `¿Estás seguro de que quieres activar ${selected} productos?`;
                    break;
                case 'deactivate':
                    message = `¿Estás seguro de que quieres desactivar ${selected} productos?`;
                    break;
            }
            
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\victo\source\repos\laravel\LaBaque\resources\views/products/index.blade.php ENDPATH**/ ?>